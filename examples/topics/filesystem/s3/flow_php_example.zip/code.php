<?php

declare(strict_types=1);

use function Flow\ETL\Adapter\Parquet\{from_parquet, to_parquet};
use function Flow\ETL\DSL\{config_builder, data_frame, from_array, overwrite, to_stream};
use function Flow\Filesystem\Bridge\AsyncAWS\DSL\{aws_s3_client, aws_s3_filesystem};
use function Flow\Filesystem\DSL\path;
use Symfony\Component\Dotenv\Dotenv;

require __DIR__ . '/vendor/autoload.php';

if (!\file_exists(__DIR__ . '/.env')) {
    print 'Example skipped. Please create .env file with AWS S3 credentials.' . PHP_EOL;

    return;
}

$dotenv = new Dotenv();
$dotenv->load(__DIR__ . '/.env');

$config = config_builder()
    ->mount(
        aws_s3_filesystem(
            $_ENV['AWS_S3_BUCKET'],
            aws_s3_client([
                'region' => $_ENV['AWS_S3_REGION'],
                'accessKeyId' => $_ENV['AWS_S3_KEY'],
                'accessKeySecret' => $_ENV['AWS_S3_SECRET'],
            ])
        )
    );

data_frame($config)
    ->read(from_array([
        ['id' => 1, 'name' => 'test'],
        ['id' => 2, 'name' => 'test'],
        ['id' => 3, 'name' => 'test'],
        ['id' => 4, 'name' => 'test'],
    ]))
    ->saveMode(overwrite())
    ->write(to_parquet(path('aws-s3://test.parquet')))
    ->run();

data_frame($config)
    ->read(from_parquet(path('aws-s3://test.parquet')))
    ->write(to_stream(__DIR__ . '/output.txt', truncate: false))
    ->run();
